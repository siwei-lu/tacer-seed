// import unzip from '~/utils/unzip'
// import os from 'os'
// import { join, resolve } from 'path'

// describe('unzip()', () => {
//   it('should unzip the file in the given path', () => {
//     const tmpdir = join(os.tmpdir(), 'unzip')
//     const target = resolve(__dirname, )
//   })
// })
